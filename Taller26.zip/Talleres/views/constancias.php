<?php
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion


if(!isset($_SESSION['login_user_sys'])){

  //mysqli_close($conexion); // Cerrando la conexion
  echo "<script type='text/javascript'>
        window.location='sesion.php'
        </script>"; // Redirecciona a la pagina de sesion
  }else{
  $usuario = $_SESSION['login_user_sys'];
  
  if($usuario!='Administrador'){
    session_destroy();
    echo "<script type='text/javascript'>
        window.location='sesion.php'
        </script>";
  
  }
  
  }


$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET["taller"];
 $calendario_seleccionado = $_GET['calendario'];
 $turno_seleccionado = $_GET['turno'];
$dia_seleccionado = $_GET['dia'];
$Fecha_inicio = $_GET['fecha_inicio'];
$Fecha_final = $_GET['fecha_final'];

//echo "<script>alert('$Fecha_inicio');</script>";


date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');




if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 
}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado';</script>";
}

/*if($calendario_seleccionado!=$año){
  echo "<script>
  window.location='taller1.1.php';
  </script>";
}*/

//$fecha_inicio_texto = $arr1[2].' de '.$m1.' del '.$arr1[0];

//echo $arr1[2].' de '.$m1.' del '.$arr1[0].' al '.$arr2[2].' de '.$m2.' del '.$arr2[0];


$con = connect($host, $port, $db_name, $db_username, $db_password);
$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );
$conexion->query("SET NAMES 'utf8'");
$con->query("SET NAMES 'utf8'");

$validar_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$filas_talleres = mysqli_query($conexion,$validar_talleres);

if(mysqli_num_rows($filas_talleres)==0){
  echo "<script type='text/javascript'>
  window.location='taller1.1.php';
  </script>";
}

while($taller = mysqli_fetch_array($filas_talleres)){
  $constancias_generadas = $taller['Constancias_generadas'];

}




if($constancias_generadas=='No'){
if(empty($Fecha_inicio)||empty($Fecha_final)){
  echo "<script>window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado';</script>";

}
}

if($constancias_generadas=='No'){
//convertir formato de fecha de inicio
$arr1 = explode('-', $Fecha_inicio);
$newDate1 = $arr1[2].'-'.$arr1[1].'-'.$arr1[0];


$m1 = "";
switch($arr1[1]){

  case '01':   $m1 = "Enero";     break;
  case '02':  $m1 = "Febrero";      break;
  case '03':  $m1 = "Marzo";      break;
  case '04':  $m1 = "Abril";      break;
  case '05':  $m1 = "Mayo";      break;
  case '06':  $m1 = "Junio";      break;
  case '07':  $m1 = "Julio";      break;
  case '08':  $m1 = "Agosto";      break;
  case '09':  $m1 = "Septiembre";      break;
  case '10':  $m1 = "Octubre";      break;
  case '11':   $m1 = "Noviembre";     break;
  case '12':   $m1 = "Diciembre";     break;

}

//convertir formato de fecha final
$arr2 = explode('-', $Fecha_final);
$newDate2 = $arr2[2].'-'.$arr2[1].'-'.$arr2[0];


$m2 = "";
switch($arr2[1]){

  case '01':   $m2 = "Enero";     break;
  case '02':  $m2 = "Febrero";      break;
  case '03':  $m2 = "Marzo";      break;
  case '04':  $m2 = "Abril";      break;
  case '05':  $m2 = "Mayo";      break;
  case '06':  $m2 = "Junio";      break;
  case '07':  $m2 = "Julio";      break;
  case '08':  $m2 = "Agosto";      break;
  case '09':  $m2 = "Septiembre";      break;
  case '10':  $m2 = "Octubre";      break;
  case '11':   $m2 = "Noviembre";     break;
  case '12':   $m2 = "Diciembre";     break;

}

}


$validar_cuenta_remitente = "SELECT * FROM correo_remitente";

$fila_cuenta_remitente = mysqli_query($conexion,$validar_cuenta_remitente);

if(mysqli_num_rows($fila_cuenta_remitente)>0){

  $i=0;
  while($cuenta = mysqli_fetch_array($fila_cuenta_remitente)){
    
    $correo_remitente[$i] = $cuenta['Correo'];
   $password_remitente[$i] = $cuenta['Contra'];
   
   $i++;
  }

}else{
  $correo_remitente[0] = "";
  $password_remitente[0] = "";
}

//arreglo de id de usuarios seleccionados para las constancias

if($constancias_generadas=='No'){
  $fecha_constacia_generada = date('Y-m-d');

$conexion->query("UPDATE mostrar_talleres SET  	Constancias_generadas='Si',Fecha_inicio='$Fecha_inicio',Fecha_final='$Fecha_final',Fecha_constancia_generada='$fecha_constacia_generada' WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'");
}


$sql = "SELECT * FROM constancias_alumnos WHERE NombreTallerista='$tallerista_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado' AND Turno = '$turno_seleccionado' AND Dia = '$dia_seleccionado';";

$result = mysqli_query($conexion,$sql);


?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<header>
    <title>Talleres</title>
</header>




<link rel="stylesheet" href="../assets/css/estilo_constancias.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php include 'header_taller.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    


<div class="fondo">



<a class="btn btn-primary talleres" id="talleres" href="taller1.2.php?tallerista=<?php echo $tallerista_seleccionado?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>">Ir a Alumnos registrados</a>


<button type='submit' class='btn btn-secondary cuenta_remitente' id='cuenta_remitente' name='cuenta_remitente' data-toggle='modal' data-target="#cuenta_remitenteModal">Cuenta del remitente</button>



<h1 class="titulo_taller">Constancias</h1>
<div class="taller_informacion">
<p id="subtitulo"> TALLERISTA: <p><?php echo "$tallerista_seleccionado"?></p> </p>
<p id="subtitulo">  TALLER: <p><?php echo "$taller_seleccionado"?></p> </p>
<p id="subtitulo">  CALENDARIO: <p> <?php echo "$calendario_seleccionado"?></p></p>
<p id="subtitulo">  TURNO: <p> <?php echo "$turno_seleccionado "?></p></p>
<p id="subtitulo">  DIA: <p> <?php echo " $dia_seleccionado" ?></p></p>
</div>

<button type='submit' class='btn btn-danger boton_enviar_todos' id="boton_enviar_todos" data-toggle='modal' data-target="#enviar_todosModal">Enviar a todos</button>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
<td>Folio</td>
    <td>Codigo</td>
    <td>Nombre Completo</td>
    <td>Correo</td>
    <td>Carrera</td>
    <td>PDF</td>
    <td></td>
   
</tr>
</thead>

<tbody>


<?php  
while($fila = mysqli_fetch_array($result)){ 

?>

<tr class="filas_secundarias" id="color_filas" >
    <td ><?php echo $fila['Folio']; ?></td>
    <td><?php echo $fila['Codigo']; ?></td>
    <td><?php echo $fila['Nombre']; ?></td>
    <td><?php echo $fila['Correo']; ?></td>
    <td><?php echo $fila['Carrera']; ?></td>
    <td WIDTH="50" ><a href="constancias_pdf.php?tallerista=<?php echo $tallerista_seleccionado ?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&id=<?php echo $fila['idUsuarios'];?>&enviar=No"><img src="../assets/img/pdf32.png" alt=""></a></a></td>
    <td><button type='submit' class='btn btn-primary boton_enviar' id="boton_enviar" data-toggle='modal' data-target="#enviar_individualModal<?php echo $fila['idUsuarios']; ?>">Enviar</button></td>
</tr>

</tbody>


<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Enviar de forma individual-->
<div class="modal fade" id="enviar_individualModal<?php echo $fila['idUsuarios'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Desea enviar constancia a: </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="constancias_pdf.php?tallerista=<?php echo $tallerista_seleccionado ?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&id=<?php echo $fila['idUsuarios'];?>&enviar=Si" method="POST">
        <div class="form-group">
            <label for="recipient-name" class="col-form-label"><?php echo $fila["Nombre"]; ?></label><br>
            <label for="recipient-name" class="col-form-label"><?php echo ' '.$fila["Correo"]; ?></label>
      
          </div>
       
          <div class="modal-footer">
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-success" id="enviar_individual" name="enviar_individual">Enviar ahora</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

<?php

}
?>

<!--constancias_pdf.php?tallerista=<?php //echo $tallerista_seleccionado ?>&taller=<?php //echo $taller_seleccionado?>&calendario=<?php //echo $calendario_seleccionado?>&turno=<?php //echo $turno_seleccionado?>&dia=<?php //echo $dia_seleccionado?>&id=<?php //echo $fila['idUsuarios'];?>&enviar=Si-->

</table>


<!--Seccion del modal deel envio de constancias a todos-->

<!-- Modal Enviar de forma general-->
<div class="modal fade" id="enviar_todosModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">¿Desea enviar las constancias a todos? </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="constancias_todos_pdf.php?tallerista=<?php echo $tallerista_seleccionado ?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>" method="POST">
        
       
          <div class="modal-footer">
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-success" id="enviar_todos" name="enviar_todos">Enviar ahora</button>
      </div>
        </form>  <!--cuenta_remitenteModal-->
      </div>
      
    </div>
  </div>
</div>

<!--Seccion del modal de la informacion de la cuenta de remitente-->

<!-- Modal Cuenta de remitente-->
<div class="modal fade" id="cuenta_remitenteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cuenta del remitente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="cerrar" onclick="reiniciar_valores()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="constancias.php?tallerista=<?php echo $tallerista_seleccionado?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&fecha_inicio=<?php echo $Fecha_inicio ?>&fecha_final=<?php echo $Fecha_final?>" method="POST"> <!--fa-solid fa-pencil-slash-->
       
         
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Correo Electrónico</label>
            <div class="input-group">
      <input id="recipient_cuenta_remitente" name = "recipient_cuenta_remitente"  type="text" Class="form-control" disabled placeholder="Escribe el nuevo correo aqui" value="<?php echo $correo_remitente[0]; ?>">
      <div class="input-group-append">
            <!--<button id="show_password" class="btn btn-primary" type="button" onclick="mostrarCuentaRemitente()" > <span class="fa fa-eye-slash icon_remitente"></span> </button>-->
            <button type="button" class="btn btn-light editar_cuenta_remitente" id="editar_cuenta_remitente" name="editar_contra_remitente" onclick="editar_campos_remitente()"><span class="fa fa-pencil edit"></span></button>
          </div>
    </div>
            <!--<input type="text" class="form-control" id="recipient_contra_admin"  name = "recipient_contra_admin" value="<?php //echo $fila["Nombre"]; ?>" required autocomplete="off">-->

          </div>
          <div class="form-group">
                   <label for="recipient-name" class="col-form-label">Contraseña</label>
          
                   <div class="input-group">
                 <input id="recipient_contra_remitente" name = "recipient_contra_remitente"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
                <div class="input-group-append">
               <button id="show_password2" class="btn btn-primary" type="button" onclick="mostrarPasswordRemitente()" > <span class="fa fa-eye-slash icon_contra_remitente"></span> </button>
               <button type="button" class="btn btn-light editar_contra_remitente" id="editar_contra_remitente" name="editar_contra_remitente" onclick="editar_campos_contra_remitente()"><span class="fa fa-pencil edit"></span></button>
              </div>
              </div>
          </div>
         
        
          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal" id="cerrar" onclick="reiniciar_valores()">Cerrar</button>
        <button type="submit" class="btn btn-primary guardar_cambios" id="btncuenta_remitente" name="btncuenta_remitente" hidden="true" onclick="desbloquear_campos()">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>
 
<!--Habilitar campos y mostrar texto de los inputs del modal de cuenta del remitente-->
<script type="text/javascript">
function mostrarCuentaRemitente(){
		var cambio = document.getElementById("recipient_cuenta_remitente");
		if(cambio.type == "password"){
			//cambio.type = "text";
			$('.icon_remitente').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_remitente').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 

  function mostrarPasswordRemitente(){
		var cambio = document.getElementById("recipient_contra_remitente");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_contra_remitente').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_contra_remitente').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 
	
  function editar_campos_remitente(){
    var cambio1 = document.getElementById("recipient_cuenta_remitente");
    var cambio2 = document.getElementById("recipient_contra_remitente");
    var cambio3_boton = document.getElementById("btncuenta_remitente");
    if(cambio1.disabled == true ){

      cambio3_boton.hidden = false;
			cambio1.disabled = false;
     
			$('.editar_cuenta_remitente').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio2.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio1.disabled = true;
     
      $('.editar_cuenta_remitente').removeClass('btn btn-dark').addClass('btn btn-light');
		}
  }

  function editar_campos_contra_remitente(){
    var cambio1 = document.getElementById("recipient_cuenta_remitente");
    var cambio2 = document.getElementById("recipient_contra_remitente");
    var cambio3_boton = document.getElementById("btncuenta_remitente");
    if(cambio2.disabled == true){
      cambio3_boton.hidden = false;
      cambio2.disabled = false;
			$('.editar_contra_remitente').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio1.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio2.disabled = true;
      $('.editar_contra_remitente').removeClass('btn btn-dark').addClass('btn btn-light');
		}

  }


  function reiniciar_valores(){
    var cambio1 = document.getElementById("recipient_cuenta_remitente");
    cambio1.disabled = true;
    var cambio2 = document.getElementById("recipient_contra_remitente");
    cambio2.disabled = true;
    cambio2.value = "";
    cambio2.type = 'password';
    var cambio3_boton = document.getElementById("btncuenta_remitente");
    cambio3_boton.hidden = true;
    $('.editar_cuenta_remitente').removeClass('btn btn-dark').addClass('btn btn-light');
    $('.editar_contra_remitente').removeClass('btn btn-dark').addClass('btn btn-light');

    $('.icon_contra_remitente').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
  }

  function desbloquear_campos(){
    var cambio1 = document.getElementById("recipient_cuenta_remitente");
    cambio1.disabled = false;
    var cambio2 = document.getElementById("recipient_contra_remitente");
    cambio2.disabled = false;


   
  }

</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>


<?php

if(isset($_POST['btncuenta_remitente'])){
  $entrar_campos_vacios = true;
  $entrar = true;

$correo = $_POST['recipient_cuenta_remitente'];
$contra_remitente = $_POST['recipient_contra_remitente'];


//validar si estan vacios los 2 campos
if(empty($correo)&&empty($contra_remitente)){
  echo '<script>alertaeNoti("Los campos estan vacios")</script>';
  $entrar_campos_vacios = false;
  $entrar = false;
}

//validar si nomas el campo correo esta vacio
if(empty($correo)&&$entrar_campos_vacios==true){
  echo '<script>alertaeNoti("El campo del correo electrónico esta vacio")</script>';
  $entrar = false;
}else if(empty($contra_remitente)&&$entrar_campos_vacios==true){    //validar si nomas el campo contraseña esta vacio
  echo '<script>alertaeNoti("El campo de la contraseña esta vacio")</script>';
  $entrar = false;
}


if($entrar == true){
//validar que el correo sea escrito correctamente
if(filter_var($correo, FILTER_VALIDATE_EMAIL)){



//validar que ya exista la cuenta del remitente en la base de datos
if(mysqli_num_rows($fila_cuenta_remitente)>0){

 

 
//validar que el correo el campo sea igual a la base de datos
 if($correo==$correo_remitente[0]){
  $con->query("UPDATE correo_remitente SET Contra = AES_ENCRYPT('$contra_remitente','CUALTOS1234567890') WHERE Correo= '$correo_remitente[0]'");

  if($con){
    echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
  }

 }else{
  $con->query("DELETE FROM correo_remitente"); 

 $con->query("INSERT INTO correo_remitente (Correo,Contra) values ('$correo',AES_ENCRYPT('$contra_remitente','CUALTOS1234567890'))");


if($con){
  echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
}

 }


}else{ //else por si es la primera vez que se agrega la cuenta de correo de remitente



//validar que los dos campos no esten vacios
if(!empty($correo)&&!empty($contra_remitente)){


  $con->query("INSERT INTO correo_remitente (Correo,Contra) values ('$correo',AES_ENCRYPT('$contra_remitente','CUALTOS1234567890'))");


if($con){
  
  echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
}
}

}

}else{
  echo '<script>alertaeNoti("Correo no válido")</script>';

}

}

}



?>



</div>
<script src="../assets/js/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>




</body>
</html>
<?php  $conexion->close();   $con=null; ?>