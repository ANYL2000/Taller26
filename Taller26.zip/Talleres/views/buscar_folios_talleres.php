<?php
include('../assets/conexion/servidor.php');

$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$con->query("SET NAMES 'utf8'");

$folio = $_POST["buscar"];


$consulta_existencia = "SELECT * FROM constancias_alumnos WHERE Folio= '$folio'";

$filas = mysqli_query($con,$consulta_existencia);

$salida= "";
if(mysqli_num_rows($filas)>0){
    $salida.='<br>';
    $salida.='<span style="position: relative; left:40px;">Resultados encontrados:</span>';
    $salida.='<br>';
   $salida.='<table class="table-responsive">
   <thead>
<tr class="fila_principal">

   <td>Folio</td>
   <td>Codigo</td>
   <td>Nombre Completo</td>
   <td>Carrera</td>
   <td>Taller</td>
   <td>Calendario</td>
</tr>
</thead>';
    while($taller = mysqli_fetch_array($filas)){

$salida.='<tr class="filas_secundarias" id="color_filas" >
<td> '.$taller['Folio'].'</td>
<td> '.$taller['Codigo'].'</td>
<td> '.$taller['Nombre'].'</td>
<td> '.$taller['Carrera'].'</td>
<td> '.$taller['NombreTaller'].'</td>
<td> '.$taller['Ingreso'].'</td>
</tr>';


    }
   $salida.='</table>';
   $salida.='<br><br><br>';
}else{
    $salida.="Sin resultados"; 
}

echo $salida;

?>